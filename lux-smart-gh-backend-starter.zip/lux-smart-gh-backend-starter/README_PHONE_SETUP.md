# LUX SMART GH — secure backend starter

This is a starter architecture, not a production-certified system. It uses:
- GitHub Pages for the public static website
- Supabase Auth, Postgres, Edge Functions and private Storage
- Paystack for checkout
- Gemini API for AI-generated project briefs

## First: secure any exposed keys
If any API key, password, or token was pasted into a chat, public repository, or website file, revoke/rotate it. Never commit `.env` or provider secrets.

## Phone-friendly setup order
1. In GitHub, create a private repository first for this backend starter. Upload the files from this ZIP. Keep secret values out of GitHub.
2. In Supabase, create a project and open SQL Editor. Paste and run `supabase/schema.sql`.
3. In Supabase, create a private Storage bucket named `deliverables`.
4. Install/use the Supabase CLI from a computer when possible to deploy Edge Functions. Deploying and testing Edge Functions is not reliably achievable from only a phone browser. If you have only a phone, use a trusted computer once, or use a browser-based development environment that supports the Supabase CLI.
5. Deploy the functions in `supabase/functions/`.
6. In Supabase Dashboard → Edge Functions → Secrets, add:
   - `PAYSTACK_SECRET_KEY` = your Paystack secret key (never the public key)
   - `GEMINI_API_KEY` = your Gemini API key
   - Supabase automatically provides `SUPABASE_URL` and server-side keys in supported deployments; check the current dashboard docs.
7. In Paystack Dashboard, configure the webhook URL as:
   `https://YOUR_PROJECT_REF.supabase.co/functions/v1/paystack-webhook`
8. Create a product/service row in `services` and set the price in pesewas (GHS amount × 100). Example: ₵25.00 = 2500.
9. Connect the front end to the deployed function URLs. Do not enable live checkout until test-mode payments, webhooks, duplicate-event handling, and file permissions are tested.
10. Test using Paystack Test Mode before enabling live payments.

## Important limitations
- The sample AI function requires a signed-in Supabase user (JWT). The frontend needs Supabase Auth.
- The sample checkout requires a service ID and signed-in customer.
- The webhook marks an order paid only after validating Paystack's signature and checking the transaction with Paystack's Verify API. It is designed to be idempotent.
- A delivered file must already exist in the private `deliverables` bucket and its path must be stored in `orders.file_path`. Uploading/generated files is a separate workflow.
- Never use a service-role/secret key in browser code.
- Add rate limiting, abuse monitoring, transactional email, backups, admin role controls, and thorough tests before production.
- This starter does not implement the complete admin dashboard, revisions workflow, refunds, tax/accounting, or automatic file generation.

## Environment variable / secret names
Set these in Supabase Edge Function Secrets, not in GitHub:
- `PAYSTACK_SECRET_KEY`
- `GEMINI_API_KEY`

Do not put secret values in `index.html`, JavaScript sent to browsers, GitHub Issues, screenshots, or public repositories.
