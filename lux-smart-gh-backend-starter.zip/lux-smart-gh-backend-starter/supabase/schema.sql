create extension if not exists pgcrypto;

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  description text not null default '',
  amount_pesewas integer not null check (amount_pesewas > 0),
  currency text not null default 'GHS' check (currency = 'GHS'),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete restrict,
  service_id uuid not null references public.services(id) on delete restrict,
  amount_pesewas integer not null check (amount_pesewas > 0),
  currency text not null default 'GHS' check (currency = 'GHS'),
  status text not null default 'pending'
    check (status in ('pending','paid','failed','refunded','cancelled')),
  paystack_reference text unique,
  paystack_transaction_id text,
  file_path text,
  paid_at timestamptz,
  delivered_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists orders_user_id_created_at_idx
  on public.orders(user_id, created_at desc);

alter table public.services enable row level security;
alter table public.orders enable row level security;

-- Public can view active service catalogue only.
create policy "Anyone can read active services"
  on public.services for select
  using (active = true);

-- Signed-in customers can read only their own orders.
create policy "Customers read their own orders"
  on public.orders for select to authenticated
  using (auth.uid() = user_id);

-- No browser-side order insert/update policy: trusted Edge Functions do that.
-- Do not add a broad authenticated write policy to orders.

insert into public.services (slug, name, description, amount_pesewas)
values
 ('starter-flyer','Flyer or Poster','One custom promotional flyer brief and creative service',2500),
 ('business-website','Business Website','Starter business website project',15000),
 ('prompt-pack','Prompt Pack','Digital prompt pack',1500)
on conflict (slug) do nothing;
