import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  try {
    const auth = req.headers.get("Authorization");
    if (!auth?.startsWith("Bearer ")) return json({ error: "Please sign in." }, 401);
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: auth } },
    });
    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError || !userData.user) return json({ error: "Please sign in again." }, 401);

    const { orderId } = await req.json();
    if (typeof orderId !== "string") return json({ error: "Invalid order." }, 400);
    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: order, error } = await admin.from("orders")
      .select("id,user_id,status,file_path")
      .eq("id", orderId).eq("user_id", userData.user.id).single();
    if (error || !order) return json({ error: "Order not found." }, 404);
    if (order.status !== "paid") return json({ error: "Payment has not been verified." }, 403);
    if (!order.file_path) return json({ error: "Your payment is verified, but your digital file is not ready yet." }, 409);

    const { data, error: urlError } = await admin.storage.from("deliverables").createSignedUrl(order.file_path, 60);
    if (urlError || !data?.signedUrl) return json({ error: "Could not create a secure download link." }, 500);
    return json({ download_url: data.signedUrl, expires_in_seconds: 60 });
  } catch (err) {
    console.error("paid-download error", err);
    return json({ error: "Could not prepare your download." }, 500);
  }
});

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
