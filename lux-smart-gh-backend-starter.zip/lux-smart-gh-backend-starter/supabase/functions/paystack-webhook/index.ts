import { createClient } from "npm:@supabase/supabase-js@2";

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  const secret = Deno.env.get("PAYSTACK_SECRET_KEY");
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRole = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!secret || !supabaseUrl || !serviceRole) return new Response("Server not configured", { status: 500 });

  try {
    const rawBody = await req.text();
    const signature = req.headers.get("x-paystack-signature");
    if (!signature) return new Response("Missing signature", { status: 401 });

    const key = await crypto.subtle.importKey(
      "raw", new TextEncoder().encode(secret),
      { name: "HMAC", hash: "SHA-512" }, false, ["sign"],
    );
    const signed = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(rawBody));
    const expected = [...new Uint8Array(signed)].map(b => b.toString(16).padStart(2, "0")).join("");
    if (!constantTimeEqual(signature.toLowerCase(), expected)) return new Response("Invalid signature", { status: 401 });

    const event = JSON.parse(rawBody);
    if (event.event !== "charge.success" || !event.data?.reference) return new Response("Ignored", { status: 200 });

    // Independently verify the transaction with Paystack before changing order status.
    const verifyRes = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(event.data.reference)}`, {
      headers: { Authorization: `Bearer ${secret}` },
    });
    if (!verifyRes.ok) return new Response("Verification unavailable", { status: 502 });
    const verified = await verifyRes.json();
    if (!verified.status || verified.data?.status !== "success") return new Response("Not successful", { status: 200 });

    const tx = verified.data;
    const admin = createClient(supabaseUrl, serviceRole);
    const { data: order, error } = await admin.from("orders")
      .select("id,status,amount_pesewas,currency,paystack_reference")
      .eq("paystack_reference", tx.reference).single();
    if (error || !order) {
      console.error("Order not found for reference", tx.reference);
      return new Response("Order not found", { status: 404 });
    }

    if (tx.currency !== order.currency || Number(tx.amount) !== order.amount_pesewas) {
      console.error("Payment amount/currency mismatch", tx.reference);
      return new Response("Amount mismatch", { status: 400 });
    }

    // Idempotency: do not process a paid order twice.
    if (order.status === "paid") return new Response("Already processed", { status: 200 });

    const { error: updateError } = await admin.from("orders").update({
      status: "paid",
      paystack_transaction_id: String(tx.id),
      paid_at: new Date().toISOString(),
    }).eq("id", order.id).eq("status", "pending");

    if (updateError) {
      console.error("Could not mark order paid", updateError);
      return new Response("Could not update order", { status: 500 });
    }

    // Important: this records verified payment only. A separate secure fulfillment workflow
    // must create/upload the purchased file and set orders.file_path before download is offered.
    return new Response("OK", { status: 200 });
  } catch (err) {
    console.error("paystack-webhook error", err);
    return new Response("Webhook processing failed", { status: 500 });
  }
});

function constantTimeEqual(a: string, b: string) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
