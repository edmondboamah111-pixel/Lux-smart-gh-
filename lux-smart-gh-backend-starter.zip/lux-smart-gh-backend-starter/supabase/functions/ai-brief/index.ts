import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const auth = req.headers.get("Authorization");
    if (!auth?.startsWith("Bearer ")) return json({ error: "Sign in to use the AI studio." }, 401);

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: auth } } },
    );
    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError || !userData.user) return json({ error: "Your session is invalid. Please sign in again." }, 401);

    const body = await req.json();
    const projectType = String(body.projectType ?? "").slice(0, 120);
    const businessType = String(body.businessType ?? "").slice(0, 160);
    const businessName = String(body.businessName ?? "").slice(0, 160);
    const goal = String(body.goal ?? "").trim().slice(0, 4000);
    if (!goal) return json({ error: "Please describe your project." }, 400);

    const key = Deno.env.get("GEMINI_API_KEY");
    if (!key) return json({ error: "AI service is not configured yet." }, 503);

    const prompt = `You are the project-brief assistant for LUX SMART GH, an affordable digital service for small businesses in Ghana.
Create a clear, practical project brief in plain text. Do not claim to have generated a finished image or website.
Project type: ${projectType}
Business type: ${businessType}
Business name: ${businessName}
Customer request: ${goal}
Include objective, audience, suggested content, visual direction, required details to confirm, and a concise next-step checklist. Do not invent phone numbers, prices, testimonials, or factual business details.`;

    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
      {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": key },
        body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
      },
    );
    if (!response.ok) {
      console.error("Gemini request failed:", response.status);
      return json({ error: "The AI service is temporarily unavailable. Your project has not been submitted as an order." }, 502);
    }
    const data = await response.json();
    const text = data?.candidates?.[0]?.content?.parts?.map((p: {text?: string}) => p.text ?? "").join("\n");
    if (!text) return json({ error: "The AI did not return a usable brief. Please try again." }, 502);
    return json({ brief: text });
  } catch (err) {
    console.error("ai-brief error", err);
    return json({ error: "Could not process this request. Please try again." }, 500);
  }
});

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
