import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const auth = req.headers.get("Authorization");
    if (!auth?.startsWith("Bearer ")) return json({ error: "Please sign in before checkout." }, 401);
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: auth } },
    });
    const { data: userData, error: userError } = await supabase.auth.getUser();
    const user = userData.user;
    if (userError || !user?.email) return json({ error: "A signed-in account with an email is required." }, 401);

    const { serviceId } = await req.json();
    if (typeof serviceId !== "string") return json({ error: "Select a valid service." }, 400);

    const { data: service, error: serviceError } = await supabase
      .from("services").select("id,name,amount_pesewas,currency,active").eq("id", serviceId).eq("active", true).single();
    if (serviceError || !service) return json({ error: "This service is unavailable." }, 404);

    const secret = Deno.env.get("PAYSTACK_SECRET_KEY");
    if (!secret) return json({ error: "Payments are not configured yet." }, 503);

    // Create a pending order before redirecting to Paystack. The price is loaded from the database,
    // never trusted from the browser.
    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: order, error: orderError } = await admin.from("orders").insert({
      user_id: user.id,
      service_id: service.id,
      amount_pesewas: service.amount_pesewas,
      currency: service.currency,
      status: "pending",
    }).select("id").single();
    if (orderError || !order) {
      console.error("Order insert failed", orderError);
      return json({ error: "Could not create your order. Please try again." }, 500);
    }

    const reference = `LSGH-${order.id}`;
    const siteUrl = Deno.env.get("SITE_URL") ?? "https://YOUR_GITHUB_USERNAME.github.io/YOUR_REPOSITORY";
    const paystackRes = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: { Authorization: `Bearer ${secret}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        email: user.email,
        amount: service.amount_pesewas,
        currency: "GHS",
        reference,
        callback_url: `${siteUrl}/?payment=return`,
        metadata: { order_id: order.id, service_id: service.id, user_id: user.id },
      }),
    });
    const paystackData = await paystackRes.json();
    if (!paystackRes.ok || !paystackData.status || !paystackData.data?.authorization_url) {
      await admin.from("orders").update({ status: "failed" }).eq("id", order.id);
      console.error("Paystack initialization failed", paystackData);
      return json({ error: "Paystack could not start checkout. Please try again." }, 502);
    }
    await admin.from("orders").update({ paystack_reference: reference }).eq("id", order.id);
    return json({ authorization_url: paystackData.data.authorization_url, reference });
  } catch (err) {
    console.error("paystack-init error", err);
    return json({ error: "Could not start checkout. Please try again." }, 500);
  }
});

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
