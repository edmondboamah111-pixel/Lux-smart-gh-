// Example only. Load Supabase JS v2 in your page and configure with your project URL
// and publishable/anon key. This public key is only safe when RLS is configured correctly.
// Never add PAYSTACK_SECRET_KEY, GEMINI_API_KEY, or SUPABASE_SERVICE_ROLE_KEY here.
//
// const { createClient } = supabase;
// const client = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);
//
// Example signed-in AI call:
// const { data: { session } } = await client.auth.getSession();
// const response = await fetch(`${SUPABASE_URL}/functions/v1/ai-brief`, {
//   method: "POST",
//   headers: {
//     "Content-Type": "application/json",
//     "Authorization": `Bearer ${session.access_token}`,
//     "apikey": SUPABASE_PUBLISHABLE_KEY
//   },
//   body: JSON.stringify({
//     projectType: "Flyer or poster",
//     businessType: "Barbershop",
//     businessName: "Example Barber",
//     goal: "Create a Christmas promotion flyer"
//   })
// });
// const result = await response.json();
//
// Example checkout call uses a real service UUID from public.services:
// const response = await fetch(`${SUPABASE_URL}/functions/v1/paystack-init`, {
//   method: "POST",
//   headers: {
//     "Content-Type": "application/json",
//     "Authorization": `Bearer ${session.access_token}`,
//     "apikey": SUPABASE_PUBLISHABLE_KEY
//   },
//   body: JSON.stringify({ serviceId: "SERVICE_UUID_FROM_DATABASE" })
// });
// const result = await response.json();
// if (result.authorization_url) location.href = result.authorization_url;
